from django.http import HttpResponse
from django.shortcuts import render , redirect
from django.contrib.auth.models import User
from django.contrib import messages
from adminapp.models import Patient
from adminapp.models import Donor 

def index(request):
    return render(request , "index.html")

def patient(request):
    return render(request , "patient.html")

def whodonate(request):
    return render(request , "whodonate.html")

def about(request):
    return render(request , "about.html")

def sign(request):
    return render(request , "sign.html")

def savedetail(request):
    if request.method=="POST":
        pusername=request.POST.get('pusername')
        pemail=request.POST.get('pemail')
        page=request.POST.get('page')
        pnumber=request.POST.get('pnumber')
        paddress=request.POST.get('paddress')
        pbloodgroup=request.POST.get('pbloodgroup')
        porgan=request.POST.get('porgan')
        pwho=request.POST.get('pwho')
        pgender=request.POST.get('pgender')
        data=Patient(pusername=pusername,pemail=pemail,page=page,pnumber=pnumber,paddress=paddress,pgender=pgender,pbloodgroup=pbloodgroup,porgan=porgan,pwho=pwho)
        data.save()
    

    else:
        return render(request,"Patient.html")
    
    return render(request,"index.html")



def donordetail(request):
    if request.method=="POST":
        name = request.POST.get('name')
        email=request.POST.get('email')
        age=request.POST.get('age')
        number=request.POST.get('number')
        address=request.POST.get('address')
        bloodgroup=request.POST.get('bloodgroup')
        organ=request.POST.get('organ')
        who=request.POST.get('who')
        gender=request.POST.get('gender')
        data2=Donor(name=name,email=email,age=age,number=number,address=address,bloodgroup=bloodgroup,gender =gender,organ=organ,who=who)
        data2.save()

    else:
        return render(request,"sign.html")
    
    return render(request,"index.html")


