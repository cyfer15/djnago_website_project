# from django.db import models
# from django.contrib.auth.models import User
# from django.core.mail import send_mail
# from django.contrib.auth.models import User
# from django.db.models.signals import post_save
# from django.dispatch import receiver




# class Patient(models.Model):
#     username = models.CharField(max_length=100)
#     email = models.EmailField()
#     age = models.PositiveIntegerField()
#     number = models.CharField(max_length=20)
#     address = models.CharField(max_length=255)
#     blood_group = models.CharField(max_length=5)
#     organ = models.CharField(max_length=20)
#     who = models.CharField(max_length=20)



# class Patient(models.Model):
#     # Define your fields here
#     pusername = models.CharField(max_length=100)
#     pemail = models.EmailField()
#     # ... other fields ...

#     # Define any other methods or properties as needed

#     def __str__(self):
#         return self.pusername
   
# @receiver(post_save, sender=Patient)
# def send_registration_email(sender, instance, created, **kwargs):
#     if created:
#         subject = 'Registration Successful'
#         message = f'Thank you for registering, {instance.pusername}!'
#         from_email = 'your-email@example.com'
#         recipient_list = [instance.pemail]
#         send_mail(subject, message, from_email, recipient_list)