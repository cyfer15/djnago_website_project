from django.shortcuts import render, redirect
from .models import Patient

def register_patient(request):
    if request.method == 'POST':
        pusername = request.POST.get('pusername')
        pemail = request.POST.get('pemail')
        page = request.POST.get('page')
        pnumber = request.POST.get('pnumber')
        paddress = request.POST.get('paddress')
        pbloodgroup = request.POST.get('pbloodgroup')
        porgan = request.POST.get('porgan')
        pWho = request.POST.get('pwho')
        pgender = request.POST.get('pgender')

        patient = Patient(
            pusername=pusername,
            pemail=pemail,
            page=page,
            pnumber=pnumber,
            paddress=paddress,
            pbloodgroup=pbloodgroup,
            porgan=porgan,
            pWho=pWho,
            pgender=pgender
        )
        patient.save()

        return redirect('success.html')  # Redirect to a success page after saving the data

    return render(request, 'patient.html')


from django.shortcuts import render, redirect
from .models import Donor

def register_donor(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        age = request.POST.get('age')
        number = request.POST.get('number')
        address = request.POST.get('address')
        bloodgroup = request.POST.get('bloodgroup')
        organ = request.POST.get('organ')
        who = request.POST.get('who')
        gender = request.POST.get('gender')

        donor = Donor(
            username=username,
            email=email,
            age=age,
            number=number,
            address=address,
            bloodgroup=bloodgroup,
            organ=organ,
            who=who,
            gender=gender
        )
        donor.save()

        return redirect('success.html')  # Redirect to a success page after saving the data

    return render(request, 'sign.html')

