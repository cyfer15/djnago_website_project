from django.contrib import admin
from .models import Patient
from .models import Donor

admin.site.register(Patient)
admin.site.register(Donor)