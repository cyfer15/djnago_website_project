from django.db import models

class Patient(models.Model):
    pusername = models.CharField(max_length=100)
    pemail = models.EmailField()
    page = models.IntegerField()
    pnumber = models.CharField(max_length=10)
    paddress = models.CharField(max_length=200)
    pbloodgroup = models.CharField(max_length=10)
    porgan = models.CharField(max_length=10)
    pwho = models.CharField(max_length=10)
    pgender=models.CharField(max_length=10)


class Donor(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    age = models.IntegerField()
    number = models.CharField(max_length=10)
    address = models.CharField(max_length=200)
    bloodgroup = models.CharField(max_length=10)
    organ = models.CharField(max_length=20,)
    who = models.CharField(max_length=20,)
    gender = models.CharField(max_length=10)